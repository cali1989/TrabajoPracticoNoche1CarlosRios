package test;

import entities.AutoClasico;
import entities.AutoNuevo;
import entities.Colectivo;
import entities.Radio;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class TestVehiculos {
    public static void main(String[] args) {

        AutoClasico autoclasico = new AutoClasico("Negro",
                "Chevrolet", "Impala");
        autoclasico.setRadio("Pioneer", 200);
        autoclasico.setPrecio(20000000);
        System.out.println("AutoClasico:"+autoclasico);

        Colectivo colectivo = new Colectivo("Blanco",
                "Mercedes", "Sprinter");
        colectivo.setRadio("Bose", 250);
        colectivo.setPrecio(500000000);
        System.out.println("Colectivo:"+colectivo);

        Radio radio = new Radio("Sony", 100);
        System.out.println("Radio:"+radio);

        AutoNuevo autoNuevo = new AutoNuevo("Rojo",
                "Ferrari", "F8");
        System.out.println("AutoNuevo:"+autoNuevo);

    }

}
