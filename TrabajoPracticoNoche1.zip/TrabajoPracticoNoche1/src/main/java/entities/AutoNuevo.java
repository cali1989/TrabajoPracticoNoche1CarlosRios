package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoNuevo extends Vehiculo {

    private Radio radio;

    public AutoNuevo(String color, String marca, String modelo) {
        super(color, marca, modelo);

        this.radio = new Radio("Sony", 120);

    }
}
