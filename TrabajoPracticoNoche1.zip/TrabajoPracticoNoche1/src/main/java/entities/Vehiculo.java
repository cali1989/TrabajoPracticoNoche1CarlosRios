package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Vehiculo {
    private String color;
    private String marca;
    private String modelo;
    private Double precio;
    private Radio radio;

    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setRadio(String marcaRadio,
            int potenciaRadio) {
        this.radio = new Radio(marcaRadio, potenciaRadio);
    }

    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" +
                marca + ", modelo=" + modelo + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

}
