package entities;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AutoClasico extends Vehiculo {
    
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
        
    }

   


   
}





