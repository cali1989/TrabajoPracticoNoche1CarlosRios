package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class Colectivo extends Vehiculo {

    public Colectivo(String color, String marca, String modelo) {
        super(color, marca, modelo);

    }

}
